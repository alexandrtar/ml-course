import json
import os
import unittest
from fastapi.testclient import TestClient
from main import app


class TestPredictService(unittest.TestCase):

    def setUp(self):
        self.client = TestClient(app)
        self.test_samples_dir = 'data/samples'
        if not os.path.exists(self.test_samples_dir):
            raise FileNotFoundError(f"Directory '{self.test_samples_dir}' not found.")

        self.tests = []
        for item in os.scandir(self.test_samples_dir):
            if item.is_file():
                with open(item.path, 'r') as f:
                    try:
                        self.tests.append(json.load(f))
                    except json.JSONDecodeError as e:
                        print(f"Error loading JSON from {item.path}: {e}")

    def test_predict__ok(self):
        if not self.tests:
            self.fail("No valid test samples found.")

        for test in self.tests:
            response = self.client.post("/predict", json=test)
            self.assertEqual(response.status_code, 200)
            self.assertIn('target', response.json())


if __name__ == "__main__":
    unittest.main()