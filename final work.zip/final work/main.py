from fastapi import FastAPI, HTTPException
import pandas as pd
from pydantic import BaseModel
from model import DataProcessor

app = FastAPI()

class PredictIn(BaseModel):
    client_id: str
    visit_date: str
    visit_time: str
    visit_number: int
    utm_source: str | None
    utm_medium: str | None
    utm_campaign: str | None
    utm_adcontent: str | None
    utm_keyword: str | None
    device_category: str | None
    device_os: str | None
    device_brand: str | None
    device_model: str | None
    device_screen_resolution: str | None
    device_browser: str | None
    geo_country: str | None
    geo_city: str | None

class PredictOut(BaseModel):
    target: int

session_file = 'data/ga_sessions.csv'
hit_file = 'data/ga_hits.csv'
processor = DataProcessor(session_file, hit_file)

@app.on_event("startup")
async def startup_event():
    processor.load_data_in_chunks(chunksize=100000)  # Загрузка данных по частям
    processor.preprocess_data()  # Предобработка данных
    processor.train_model()  # Обучение модели

@app.get("/")
async def read_root():
    return {"message": "Welcome to the Data Processor API"}

@app.get("/sessions")
async def get_sessions():
    if processor.sessions is not None:
        return processor.sessions.to_dict(orient="records")
    return {"error": "Sessions not loaded yet."}

@app.get("/hits")
async def get_hits():
    if processor.hits is not None:
        return processor.hits.to_dict(orient="records")
    return {"error": "Hits not loaded yet."}

@app.get('/status')
def status():
    return "I'm OK"

@app.post('/predict', response_model=PredictOut)
def predict(predict_in: PredictIn):
    if processor.model is None:
        raise HTTPException(status_code=500, detail="Model not trained yet.")

    df = pd.DataFrame.from_dict([predict_in.dict()])
    prediction = processor.model.predict(df)

    return {
        'target': prediction[0]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)
