import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, classification_report, confusion_matrix, average_precision_score
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import OneHotEncoder


class DataProcessor:
    def __init__(self, session_file, hit_file):
        self.session_file = session_file
        self.hit_file = hit_file
        self.sessions = None
        self.hits = None
        self.data = None
        self.model = None

    def load_data_in_chunks(self, chunksize=100000):
        """
        Загружает данные из CSV файлов по частям (чанками).

        :param chunksize: Количество строк для загрузки за один раз.
        """
        session_chunks = []
        hit_chunks = []

        for chunk in pd.read_csv(self.session_file, chunksize=chunksize, low_memory=False,
                                 dtype={'session_id': 'str', 'event_action': 'str'}):
            session_chunks.append(chunk)

        for chunk in pd.read_csv(self.hit_file, chunksize=chunksize, low_memory=False,
                                 dtype={'session_id': 'str'}):
            hit_chunks.append(chunk)

        self.sessions = pd.concat(session_chunks, ignore_index=True)
        self.hits = pd.concat(hit_chunks, ignore_index=True)

    def preprocess_data(self):
        if self.sessions is None or self.hits is None:
            raise ValueError("Данные не загружены. Пожалуйста, сначала вызовите load_data_in_chunks().")
        self.sessions.drop_duplicates(inplace=True)
        self.hits.drop_duplicates(inplace=True)
        self.data = self.sessions.merge(self.hits, on='session_id', how='left')

    def save_data(self, filename):
        self.data.to_csv(filename, index=False)

    def reduce_data(self, fraction=0.3):
        return self.data.sample(frac=fraction, random_state=42)

    def create_target_variable(self, target_actions):
        self.data['target'] = self.data['event_action'].isin(target_actions).astype(int)
        self.data.loc[self.data['target'] == 0, 'event_action'] = 'unknown'

    def classify_utm_source(self):
        def classify(source):
            high = ['ZpYIoDJMcFzVoPFsHGJL', 'fDLlAcSmythWSCVMvqvL']
            medium = ['kjsLglQLzykiRbcDiGcD', 'bByPQxmDaMXgpHeypKSM']
            social_sources = ['QxAxdyPLuQMEcrdZWdWb', 'MvfHsxITijuriZxsqZqt', 'ISrKoXQCxqqYvAZICvjs',
                              'IZEXUFLARCUMynmHNBGo', 'PlbkrSYoHuZBWfYjYnfw', 'gVRrcxiDQubJiljoTbGm']
            if source in high:
                return 'high'
            elif source in medium:
                return 'medium'
            elif source in social_sources:
                return 'social'
            else:
                return 'low'

        self.data['utm_source_classification'] = self.data['utm_source'].apply(classify)

    def assign_source_target(self):
        self.data['source_target'] = self.data.apply(
            lambda row: 1 if row['utm_source_classification'] in ['high', 'medium', 'social'] else 0, axis=1
        )

        self.data['utm_source'] = self.data['utm_source'].fillna('unknown')
        self.data.loc[self.data['source_target'] == 0, 'utm_source'] = 'unknown'

    def classify_media_code(self):
        def classify(code):
            high = ['LTuZkdKfxRGVceoWkVyg', 'LEoPHuyFvzoNfnzGgfcd']
            medium = ['gecBYcKZCPMcVYdSSzKP', 'FTjNLDyTrXaWYgZymFkV']
            if code in high:
                return 'high'
            elif code in medium:
                return 'medium'
            else:
                return 'low'

        self.data['media_company'] = self.data['utm_campaign'].apply(classify)

    def get_media_target(self):
        self.data['media_target'] = self.data.apply(
            lambda row: 1 if (row['media_company'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )
        self.data.loc[self.data['media_target'] == 0, 'utm_campaign'] = 'unknown'

    def classify_media_adcontents(self):
        def classify(adcontents):
            high = ['JNHcPlZPxEMWDnRiyoBf']
            medium = ['vCIpmpaGBnIQhyYNkXqp']
            if adcontents in high:
                return 'high'
            elif adcontents in medium:
                return 'medium'
            else:
                return 'low'

        self.data['media_adcontents'] = self.data['utm_adcontent'].apply(classify)

    def get_media_adcontents_target(self):
        self.data['media_adcontents_target'] = self.data.apply(
            lambda row: 1 if (row['media_adcontents'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )
        self.data.loc[self.data['media_adcontents_target'] == 0, 'utm_adcontent'] = 'unknown'

    def classify_media_keyword(self):
        def classify(keyword):
            high = ['puhZPIYqKXeFPaUviSjo']
            medium = ['hAmNSZmQkKQKAjZEGlgb', 'ITfrGJNwVsHBGJMAKoct']
            if keyword in high:
                return 'high'
            elif keyword in medium:
                return 'medium'
            else:
                return 'low'

        self.data['media_keyword'] = self.data['utm_keyword'].apply(classify)

    def get_media_keyword_target(self):
        self.data['media_keyword_target'] = self.data.apply(
            lambda row: 1 if (row['media_keyword'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['media_keyword_target'] == 0, 'utm_keyword'] = 'unknown'

        self.data['device_brand'] = self.data['device_brand'].replace('(not set)', 'Huawei')

    def classify_device_brand(self):
        def classify(brand):
            high = ['Apple', 'Samsung', 'Xiaomi', 'Huawei', '(not set)']
            medium = ['Realme', 'OPPO', 'Vivo']
            if brand in high:
                return 'high'
            elif brand in medium:
                return 'medium'
            else:
                return 'low'

        self.data['device_brand_category'] = self.data['device_brand'].apply(classify)

    def get_brand_target(self):
        self.data['device_brand_target'] = self.data.apply(
            lambda row: 1 if row['device_brand_category'] in ['high', 'medium'] else 0, axis=1
        )

        self.data.loc[self.data['device_brand_target'] == 0, 'device_brand'] = 'unknown'

    def classify_device_os(self):
        def classify(device):
            high = ['Android', 'iOS']
            medium = ['Windows', 'Macintosh']
            if device in high:
                return 'high'
            elif device in medium:
                return 'medium'
            else:
                return 'low'

        self.data['device_os_category'] = self.data['device_os'].apply(classify)

    def get_device_os_target(self):
        self.data['device_os_target'] = self.data.apply(
            lambda row: 1 if row['device_os_category'] in ['high', 'medium'] and row['target'] == 1 else 0, axis=1
        )

        self.data['is_mobile'] = self.data.apply(
            lambda row: 1 if row['device_category'] == 'mobile' and row['target'] == 1 else 0, axis=1)
        self.data['is_desktop'] = self.data.apply(
            lambda row: 1 if row['device_category'] == 'desktop' and row['target'] == 1 else 0, axis=1)
        self.data['is_tablet'] = self.data.apply(
            lambda row: 1 if row['device_category'] == 'tablet' and row['target'] == 1 else 0, axis=1)


    def fill_device_os(self):
        def fill_os(row):
            unknown_values = ['BlackBerry', 'Chrome OS', 'Tizen', 'Firefox OS', 'Nokia', 'Windows Phone', 'Linux', 'Samsung']
            if row['device_os'] in unknown_values:
                return 'unknown'
            if row['device_os'] == '(not set)':
                if row['device_category'] == 'mobile':
                    return 'iOS' if row['device_brand'] == 'Apple' else 'Android'
                elif row['device_category'] == 'desktop':
                    return 'Windows' if row['device_screen_resolution'] == '1920x1080' or row['device_brand'] in ['Windows'] else 'Macintosh'
                elif row['device_category'] == 'tablet':
                    return 'iOS' if row['device_brand'] == 'Apple' else 'Android'
                return 'unknown'
            return row['device_os']

        self.data['device_os'] = self.data.apply(fill_os, axis=1)
        self.data['device_os'] = self.data['device_os'].fillna('unknown')
        self.data.drop(columns=['device_model'], inplace=True)
        self.data['hit_date'] = pd.to_datetime(self.data['hit_date'])
        self.data['visit_date'] = pd.to_datetime(self.data['visit_date'])

    def fill_hit_date(self):
        if pd.notnull(self.data['hit_date']):
            return self.data['hit_date']
        return self.data['visit_date']

        self.data['hit_date'] = self.data.apply(fill_hit_date, axis=1)
        self.data['hit_date'] = self.data['hit_date'].dt.strftime('%Y-%m-%d')

    def calculate_outliers(self):
        q25 = self.data.quantile(0.25)
        q75 = self.data.quantile(0.75)
        iqr = q75 - q25
        boundaries = [q25 - 1.5 * iqr, q75 + 1.5 * iqr]
        return boundaries

        boundaries = calculate_outliers(self.data['hit_time'])
        max_hit_time = round(boundaries[1])
        boundaries = calculate_outliers(self.data['visit_number'])
        max_visit_number = round(boundaries[1])

        self.data.loc[self.data['visit_number'] > max_visit_number, 'visit_number'] = max_visit_number
        self.data.loc[self.data['hit_time'] > max_hit_time, 'hit_time'] = max_hit_time
        mean_value = self.data['hit_time'].mean()
        self.data['hit_time'] = self.data['hit_time'].fillna(mean_value)
        hit_median_value = self.data['hit_number'].median()
        self.data['hit_number'] = self.data['hit_number'].fillna(hit_median_value)
        self.data.drop(columns=['hit_type'], inplace=True)

    def classify_referer(self):
        def classify(referer):
            high = ['HbolMJUevblAbkHClEQa']
            return 'high' if referer in high else 'low'

        self.data['referer_category'] = self.data['hit_referer'].apply(classify)

    def get_referer_target(self):
        self.data['referer_target'] = self.data.apply(
            lambda row: 1 if (row['referer_category'] == 'high') and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['referer_target'] == 0, 'hit_referer'] = 'unknown'
        self.data.drop(columns=['hit_page_path'], inplace=True)

    def classify_event(self):
        def classify(event):
            high = ['sub_button_click']
            medium = ['sub_submit']
            if event in high:
                return 'high'
            elif event in medium:
                return 'medium'
            else:
                return 'low'

        self.data['event_category_classify'] = self.data['event_category'].apply(classify)

    def get_event_category_target(self):
        self.data['event_category_target'] = self.data.apply(
            lambda row: 1 if (row['event_category_classify'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['event_category_target'] == 0, 'event_category'] = 'unknown'

    def classify_label(self):
        def classify(label):
            high = ['EsLbNNEnCkXWoaesnKlS']
            medium = ['DrwJcHfmgRDbfayCKOrQ', 'KclpemfoHstknWHFiLit', 'nsPPIRqjxBefONGPpnsF', 'ZaZuwAXOKlbzyhUqtnmk', 'KuMiABMMbspIDDhiCNVS']
            if label in high:
                return 'high'
            elif label in medium:
                return 'medium'
            else:
                return 'low'

        self.data['event_label_classify'] = self.data['event_label'].apply(classify)

    def get_event_label_category_target(self):
        self.data['event_label_category_target'] = self.data.apply(
            lambda row: 1 if (row['event_label_classify'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['event_label_category_target'] == 0, 'event_label'] = 'unknown'
        self.data.drop(columns=['event_value'], inplace=True)
        self.data.drop(columns=['client_id'], inplace=True)

    def extract_time_features(self):
        self.data['day_of_week'] = self.data['visit_date'].dt.dayofweek
        self.data['hour_of_day'] = self.data['visit_time'].apply(lambda x: int(x.split(':')[0]))

    def create_time_based_features(self):
        self.data['is_monday'] = ((self.data['day_of_week'] == 0) & (self.data['target'] == 1)).astype(int)
        self.data['is_tuesday'] = ((self.data['day_of_week'] == 1) & (self.data['target'] == 1)).astype(int)
        self.data['is_traffic_time'] = ((self.data['hour_of_day'] >= 10) & (self.data['hour_of_day'] <= 18) & (self.data['target'] == 1)).astype(int)

    def categorize_visits(self):
        visits_count = self.data.groupby('session_id')['visit_number'].max().reset_index()
        visits_count.columns = ['session_id', 'visits_groups']
        self.data = pd.merge(self.data, visits_count, on='session_id')

        def categorize(visits_groups):
            if visits_groups == 1:
                return 'low'
            elif visits_groups == 2:
                return 'medium'
            elif visits_groups == 3:
                return 'high'
            elif visits_groups >= 4:
                return 'expert'
            else:
                return 'unknown'

        self.data['visit_category'] = self.data['visits_groups'].apply(categorize)
        self.data.drop(columns=['visits_groups'], inplace=True)

    def classify_utm_medium(self):
        def classify(medium):
            high = ['banner', 'cpc', 'organic', 'referral', '(none)']
            medium_values = ['cpm', 'push']
            if medium in high:
                return 'high'
            elif medium in medium_values:
                return 'medium'
            else:
                return 'low'

        self.data['medium_target'] = self.data['utm_medium'].apply(classify)

    def get_medium_target(self):
        self.data['utm_medium_target'] = self.data.apply(
            lambda row: 1 if (row['medium_target'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

    def replace_utm_medium_based_on_social_traffic(self):
        if self.data['medium_target'] == 'low':
            return 'unknown'
        return self.data['utm_medium']

        self.data['utm_medium'] = self.data.apply(replace_utm_medium_based_on_social_traffic, axis=1)
        self.data['utm_medium'] = self.data['utm_medium'].replace('(none)', 'organic')
        self.data['traffic_type'] = 'paid'
        self.data.loc[self.data['utm_medium'].isin(['organic', 'referral', '(none)']), 'traffic_type'] = 'organic'

    def classify_resolution(self):
        def classify(resolution):
            high = ['414x896', '1920x1080', '375x812']
            medium = ['393x851', '412x915', '375x667', '360x800']
            if resolution in high:
                return 'high'
            elif resolution in medium:
                return 'medium'
            else:
                return 'low'

        self.data['device_screen_resolution_category'] = self.data['device_screen_resolution'].apply(classify)

    def get_resolution_target(self):
        self.data['resolution_target'] = self.data.apply(
            lambda row: 1 if (row['device_screen_resolution_category'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

    def classify_browser(self):
        def classify(browser):
            high = ['Chrome']
            medium = ['Safari', 'YaBrowser']
            if browser in high:
                return 'high'
            elif browser in medium:
                return 'medium'
            else:
                return 'low'

    def get_browser_target(self):
        self.data['browser_target'] = self.data.apply(
            lambda row: 1 if (row['device_browser_category'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

        self.data['device_browser_category'] = self.data['device_browser'].apply(self)
        self.data.loc[self.data['browser_target'] == 0, 'device_browser'] = 'unknown'

    def classify_country(self):
        def classify(country):
            high = ['Russia']
            return 'high' if country in high else 'low'

        self.data['country_category'] = self.data['geo_country'].apply(classify)

    def get_country_target(self):
        self.data['country_target'] = self.data.apply(
            lambda row: 1 if (row['country_category'] == 'high') and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['country_target'] == 0, 'geo_country'] = 'unknown'

    def classify_city(self):
        def classify(city):
            high = ['Moscow']
            medium = ['Saint Petersburg']
            if city in high:
                return 'high'
            elif city in medium:
                return 'medium'
            else:
                return 'low'

        self.data['city_category'] = self.data['geo_city'].apply(classify)

    def get_city_target(self):
        self.data['city_target'] = self.data.apply(
            lambda row: 1 if (row['city_category'] in ['high', 'medium']) and (row['target'] == 1) else 0, axis=1
        )

        self.data.loc[self.data['city_target'] == 0, 'geo_city'] = 'unknown'

    def train_model(self):
        # Кодируем категориальные переменные
        categorical_cols = self.data.select_dtypes(include=['object']).columns

        # Приведение всех значений в категориальных столбцах к строковому типу
        for col in categorical_cols:
            self.data[col] = self.data[col].astype(str)

        # Проверка на наличие пропущенных значений
        if self.data[categorical_cols].isnull().any().any():
            print("Внимание: найдены пропущенные значения в категориальных столбцах. Заполнение пропусков.")
            self.data[categorical_cols] = self.data[categorical_cols].fillna('unknown')

        encoder = OneHotEncoder(sparse_output=False)
        encoded_cats = encoder.fit_transform(self.data[categorical_cols])
        encoded_df = pd.DataFrame(encoded_cats, columns=encoder.get_feature_names_out(categorical_cols))

        # Объединяем закодированные данные с остальными
        df = pd.concat([self.data.reset_index(drop=True), encoded_df.reset_index(drop=True)], axis=1)
        df.drop(categorical_cols, axis=1, inplace=True)

        # Разделяем данные на признаки и целевую переменную
        X = df.drop('target', axis=1)
        y = df['target']

        # Разделяем на обучающую и тестовую выборки
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

        # Применяем SMOTE для балансировки классов
        smote = SMOTE(random_state=42)
        X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

        # Обучаем модель
        self.model = RandomForestClassifier(class_weight='balanced', random_state=42)
        self.model.fit(X_resampled, y_resampled)

        # Оцениваем модель
        self.evaluate_model(X_train, y_train, X_test, y_test)

    def evaluate_model(self, X_train, y_train, X_test, y_test):
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)[:, 1]

        roc_auc = roc_auc_score(y_test, y_pred_proba)
        print(f'ROC-AUC: {roc_auc:.4f}')
        print(classification_report(y_test, y_pred))
        print(confusion_matrix(y_test, y_pred))

        # Кросс-валидация
        scores = cross_val_score(self.model, X_test, y_test, cv=5, scoring='roc_auc')
        print("ROC-AUC scores for each fold:", scores)
        print("Mean ROC-AUC score:", np.mean(scores))

        # Изменение метрик: AUC-PR
        y_scores = self.model.predict_proba(X_test)[:, 1]
        auc_pr = average_precision_score(y_test, y_scores)
        print("AUC-PR:", auc_pr)

        # Оценка на обучающей выборке
        y_train_pred = self.model.predict_proba(X_train)[:, 1]
        train_roc_auc = roc_auc_score(y_train, y_train_pred)
        train_auc_pr = average_precision_score(y_train, y_train_pred)

        # Оценка на тестовой выборке
        y_test_pred = self.model.predict_proba(X_test)[:, 1]
        test_roc_auc = roc_auc_score(y_test, y_test_pred)
        test_auc_pr = average_precision_score(y_test, y_test_pred)

        # Выводим результаты
        print("Train ROC-AUC:", train_roc_auc)
        print("Train AUC-PR:", train_auc_pr)
        print("Test ROC-AUC:", test_roc_auc)
        print("Test AUC-PR:", test_auc_pr)

        # Проверка на переобучение
        if train_roc_auc - test_roc_auc > 0.1 or train_auc_pr - test_auc_pr > 0.1:
            print("Модель может быть переобучена.")
        else:
            print("Модель не показывает признаков переобучения.")
